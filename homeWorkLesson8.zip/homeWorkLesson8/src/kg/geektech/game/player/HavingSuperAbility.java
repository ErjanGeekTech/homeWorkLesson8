package kg.geektech.game.player;

public interface HavingSuperAbility {
    void appleSuperAbility(Boss boss, Hero[] heroes);
}
