package kg.geektech.game.player;

public enum SuperAbility {
    HEAL, CRITICAL_DAMAGE, BOOST, SAVE_DAMAGE_AND_REVERT
}
